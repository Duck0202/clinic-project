export interface Patient {
  id: string
  name: string
  age: number
  gender: 'male' | 'female' | 'other'
  phone: string
  address: string
  medical_history?: string
  chronic_diseases?: string
  allergies?: string
  created_at: string
  updated_at: string
}

export interface Appointment {
  id: string
  patient_id: string
  appointment_date: string
  symptoms: string
  examination: string
  diagnosis: string
  vital_signs: {
    temperature?: number
    heart_rate?: number
    spo2?: number
    respiratory_rate?: number
    blood_pressure?: string
  }
  medications?: string[]
  investigations?: string[]
  cost: number
  status: 'scheduled' | 'completed' | 'cancelled'
  created_at: string
  updated_at: string
}

export interface Medicine {
  id: string
  name: string
  type: string
  expiry_date: string
  purchase_price: number
  selling_price: number
  stock_quantity: number
  minimum_stock: number
  created_at: string
  updated_at: string
}

export interface Investigation {
  id: string
  name: string
  price: number
  normal_range?: string
  created_at: string
  updated_at: string
}

export interface Finance {
  id: string
  appointment_id: string
  amount: number
  payment_type: 'cash' | 'card' | 'insurance'
  date: string
  description: string
  created_at: string
}

export interface Settings {
  id: string
  clinic_name: string
  clinic_logo?: string
  language: string
  medicine_types: string[]
  investigation_types: string[]
  created_at: string
  updated_at: string
}