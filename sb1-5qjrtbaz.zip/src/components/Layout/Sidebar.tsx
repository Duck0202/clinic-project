import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  Pill, 
  FlaskConical, 
  DollarSign, 
  Settings, 
  LogOut,
  Activity
} from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

const Sidebar: React.FC = () => {
  const { signOut } = useAuth()
  const navigate = useNavigate()

  const handleSignOut = async () => {
    await signOut()
    navigate('/login')
  }

  const menuItems = [
    { icon: LayoutDashboard, label: 'ໜ້າຫຼັກ', path: '/' },
    { icon: Users, label: 'ຜູ້ປ່ວຍ', path: '/patients' },
    { icon: Calendar, label: 'ການນັດຫມາຍ', path: '/appointments' },
    { icon: Pill, label: 'ຢາ', path: '/medicines' },
    { icon: FlaskConical, label: 'ການກວດ', path: '/investigations' },
    { icon: DollarSign, label: 'ການເງິນ', path: '/finance' },
    { icon: Settings, label: 'ຕັ້ງຄ່າ', path: '/settings' },
  ]

  return (
    <div className="bg-blue-600 text-white w-64 min-h-screen flex flex-col">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <Activity className="h-8 w-8" />
          <h1 className="text-xl font-bold">ຄລີນິກລາງ</h1>
        </div>
      </div>

      <nav className="flex-1 px-4">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                    isActive
                      ? 'bg-blue-700 text-white'
                      : 'text-blue-100 hover:bg-blue-500 hover:text-white'
                  }`
                }
              >
                <item.icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4">
        <button
          onClick={handleSignOut}
          className="flex items-center space-x-3 px-4 py-3 w-full text-left text-blue-100 hover:bg-blue-500 hover:text-white rounded-lg transition-colors duration-200"
        >
          <LogOut className="h-5 w-5" />
          <span className="font-medium">ອອກຈາກລະບົບ</span>
        </button>
      </div>
    </div>
  )
}

export default Sidebar