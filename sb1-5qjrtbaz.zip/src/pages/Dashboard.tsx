import React, { useEffect, useState } from 'react'
import { Users, Calendar, DollarSign, TrendingUp } from 'lucide-react'
import Layout from '../components/Layout/Layout'
import { supabase } from '../lib/supabase'

interface DashboardStats {
  todayPatients: number
  todayRevenue: number
  todayAppointments: number
  monthlyRevenue: number
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    todayPatients: 0,
    todayRevenue: 0,
    todayAppointments: 0,
    monthlyRevenue: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0]
      const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]

      // Fetch today's appointments
      const { data: todayAppointments } = await supabase
        .from('appointments')
        .select('*')
        .gte('appointment_date', today)
        .lt('appointment_date', new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0])

      // Fetch today's revenue
      const { data: todayFinance } = await supabase
        .from('finance')
        .select('amount')
        .gte('date', today)
        .lt('date', new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0])

      // Fetch monthly revenue
      const { data: monthlyFinance } = await supabase
        .from('finance')
        .select('amount')
        .gte('date', startOfMonth)

      const todayRevenue = todayFinance?.reduce((sum, record) => sum + record.amount, 0) || 0
      const monthlyRevenue = monthlyFinance?.reduce((sum, record) => sum + record.amount, 0) || 0

      setStats({
        todayPatients: new Set(todayAppointments?.map(apt => apt.patient_id)).size || 0,
        todayRevenue,
        todayAppointments: todayAppointments?.length || 0,
        monthlyRevenue,
      })
    } catch (error) {
      console.error('Error fetching dashboard stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const statCards = [
    {
      title: 'ຜູ້ປ່ວຍວັນນີ້',
      value: stats.todayPatients,
      icon: Users,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'ການນັດຫມາຍວັນນີ້',
      value: stats.todayAppointments,
      icon: Calendar,
      color: 'bg-green-500',
      bgColor: 'bg-green-50',
    },
    {
      title: 'ລາຍຮັບວັນນີ້',
      value: `${stats.todayRevenue.toLocaleString()} ກີບ`,
      icon: DollarSign,
      color: 'bg-yellow-500',
      bgColor: 'bg-yellow-50',
    },
    {
      title: 'ລາຍຮັບເດືອນນີ້',
      value: `${stats.monthlyRevenue.toLocaleString()} ກີບ`,
      icon: TrendingUp,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50',
    },
  ]

  if (loading) {
    return (
      <Layout title="ໜ້າຫຼັກ">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout title="ໜ້າຫຼັກ">
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            ຍິນດີຕ້ອນຮັບສູ່ລະບົບຄຸ້ມຄອງຄລີນິກ
          </h2>
          <p className="text-gray-600">
            ພາບລວມຂໍ້ມູນການດໍາເນີນງານຂອງຄລີນິກໃນມື້ນີ້
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((card, index) => (
            <div
              key={index}
              className={`${card.bgColor} p-6 rounded-lg border border-gray-200 transition-transform duration-200 hover:scale-105`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">
                    {card.title}
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {card.value}
                  </p>
                </div>
                <div className={`${card.color} p-3 rounded-full`}>
                  <card.icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            ການດໍາເນີນງານໄວ
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200">
              <Users className="h-4 w-4" />
              <span>ເພີ່ມຌູ້ປ່ວຍໃໝ່</span>
            </button>
            <button className="flex items-center justify-center space-x-2 bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200">
              <Calendar className="h-4 w-4" />
              <span>ສ້າງການນັດຫມາຍ</span>
            </button>
            <button className="flex items-center justify-center space-x-2 bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 transition-colors duration-200">
              <DollarSign className="h-4 w-4" />
              <span>ບັນທຶກລາຍຮັບ</span>
            </button>
          </div>
        </div>

        {/* Recent Activity Placeholder */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            ກິດຈະກໍາຫຼ້າສຸດ
          </h3>
          <div className="text-center py-8 text-gray-500">
            <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>ຍັງບໍ່ມີກິດຈະກໍາໃນມື້ນີ້</p>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default Dashboard