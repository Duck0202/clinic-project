/*
  # Insert sample data for testing

  1. Sample Data
    - Sample medicines with Lao names
    - Sample investigations
    - Sample patients
    - Sample appointments

  This data helps test the application functionality
*/

-- Insert sample medicines
INSERT INTO medicines (name, type, expiry_date, purchase_price, selling_price, stock_quantity, minimum_stock) VALUES
('ພາຣາເຊຕາມອນ 500mg', 'ຢາເມັດ', '2025-12-31', 0.50, 1.00, 1000, 50),
('ອາມອກຊີຊິລິນ 500mg', 'ຢາແຄບຊູນ', '2025-06-30', 2.00, 4.00, 500, 25),
('ອີບູໂປຣເຟນ 400mg', 'ຢາເມັດ', '2025-09-15', 1.00, 2.00, 300, 30),
('ວິຕາມິນ C', 'ຢາເມັດ', '2026-03-20', 3.00, 6.00, 200, 20),
('ຢານ້ຳແກ້ໄອ', 'ຢານ້ຳ', '2025-08-10', 5.00, 10.00, 100, 10)
ON CONFLICT DO NOTHING;

-- Insert sample investigations
INSERT INTO investigations (name, price, normal_range) VALUES
('ກວດເລືອດທົ່ວໄປ (CBC)', 50000, 'WBC: 4,000-11,000/μL, RBC: 4.5-5.5 million/μL'),
('ກວດນ້ຳຕານ', 25000, '70-100 mg/dL (ຖ້າບໍ່ກິນເຂົ້າ)'),
('ກວດປັດສະວະ', 30000, 'ປົກກະຕິ: ບໍ່ມີໂປຣຕີນ, ບໍ່ມີນ້ຳຕານ'),
('X-Ray ໜ້າເອິກ', 80000, 'ປົກກະຕິ: ບໍ່ມີຮ່ອງຮອຍຜິດປົກກະຕິ'),
('ECG', 60000, 'ຈັງຫວະຫົວໃຈປົກກະຕິ: 60-100 bpm')
ON CONFLICT DO NOTHING;

-- Insert sample patients
INSERT INTO patients (name, age, gender, phone, address, medical_history) VALUES
('ນາງ ສົມຈິດ ພົມມະວົງ', 45, 'female', '020-5555-1234', 'ບ້ານ ນາໄຜ່, ເມືອງ ຈັນທະບູລີ, ນະຄອນຫຼວງວຽງຈັນ', 'ມີປະຫວັດເປັນເບົາຫວານ'),
('ທ້າວ ບຸນມີ ສີວິໄລ', 32, 'male', '020-7777-5678', 'ບ້ານ ສີສັດຕະນາກ, ເມືອງ ສີສັດຕະນາກ, ນະຄອນຫຼວງວຽງຈັນ', 'ສຸຂະພາບດີ'),
('ນາງ ມາລີ ວົງສະຫວັນ', 28, 'female', '020-9999-9876', 'ບ້ານ ດອນກອຍ, ເມືອງ ຫາດຊາຍຟອງ, ນະຄອນຫຼວງວຽງຈັນ', 'ມີປະຫວັດພຸມແພ້ຢາປະຕິຊີວະນະ')
ON CONFLICT DO NOTHING;