/*
  # Create settings table

  1. New Tables
    - `settings`
      - `id` (uuid, primary key)
      - `clinic_name` (text, required)
      - `clinic_logo` (text for logo URL)
      - `language` (text, default 'lo')
      - `medicine_types` (text array)
      - `investigation_types` (text array)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `settings` table
    - Add policy for authenticated users to manage settings

  3. Initial Data
    - Insert default settings for Lao clinic
*/

CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_name text NOT NULL DEFAULT 'ຄລີນິກລາວ',
  clinic_logo text DEFAULT '',
  language text NOT NULL DEFAULT 'lo',
  medicine_types text[] DEFAULT ARRAY[
    'ຢາເມັດ',
    'ຢາແຄບຊູນ',
    'ຢານ້ຳ',
    'ຢາຄີມ',
    'ຢາສີດ',
    'ຢາຢອດ',
    'ຢາທາ'
  ],
  investigation_types text[] DEFAULT ARRAY[
    'ກວດເລືອດ',
    'ກວດປັດສະວະ',
    'X-Ray',
    'ECG',
    'Ultrasound',
    'CT Scan',
    'MRI'
  ],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage settings"
  ON settings
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_settings_updated_at
  BEFORE UPDATE ON settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default settings
INSERT INTO settings (clinic_name, language) 
VALUES ('ຄລີນິກລາວ', 'lo')
ON CONFLICT DO NOTHING;