/*
  # Create investigations table

  1. New Tables
    - `investigations`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `price` (decimal, required)
      - `normal_range` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `investigations` table
    - Add policy for authenticated users to manage investigation data
*/

CREATE TABLE IF NOT EXISTS investigations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price decimal(10,2) NOT NULL CHECK (price >= 0),
  normal_range text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE investigations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage investigations"
  ON investigations
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_investigations_updated_at
  BEFORE UPDATE ON investigations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();