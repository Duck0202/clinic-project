/*
  # Create appointments table

  1. New Tables
    - `appointments`
      - `id` (uuid, primary key)
      - `patient_id` (uuid, foreign key to patients)
      - `appointment_date` (date, required)
      - `symptoms` (text)
      - `examination` (text)
      - `diagnosis` (text)
      - `vital_signs` (jsonb for structured data)
      - `medications` (text array)
      - `investigations` (text array)
      - `cost` (decimal, required)
      - `status` (text, required - scheduled/completed/cancelled)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `appointments` table
    - Add policy for authenticated users to manage appointment data
*/

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_date date NOT NULL,
  symptoms text DEFAULT '',
  examination text DEFAULT '',
  diagnosis text DEFAULT '',
  vital_signs jsonb DEFAULT '{}',
  medications text[] DEFAULT '{}',
  investigations text[] DEFAULT '{}',
  cost decimal(10,2) NOT NULL DEFAULT 0 CHECK (cost >= 0),
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage appointments"
  ON appointments
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_appointments_updated_at
  BEFORE UPDATE ON appointments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);