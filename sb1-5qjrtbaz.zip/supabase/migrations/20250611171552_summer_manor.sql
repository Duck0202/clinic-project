/*
  # Create medicines table

  1. New Tables
    - `medicines`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `type` (text, required)
      - `expiry_date` (date, required)
      - `purchase_price` (decimal, required)
      - `selling_price` (decimal, required)
      - `stock_quantity` (integer, required)
      - `minimum_stock` (integer, default 10)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `medicines` table
    - Add policy for authenticated users to manage medicine data
*/

CREATE TABLE IF NOT EXISTS medicines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  expiry_date date NOT NULL,
  purchase_price decimal(10,2) NOT NULL CHECK (purchase_price >= 0),
  selling_price decimal(10,2) NOT NULL CHECK (selling_price >= 0),
  stock_quantity integer NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  minimum_stock integer NOT NULL DEFAULT 10 CHECK (minimum_stock >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE medicines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage medicines"
  ON medicines
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER update_medicines_updated_at
  BEFORE UPDATE ON medicines
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();