/*
  # Create investigation results table

  1. New Tables
    - `investigation_results`
      - `id` (uuid, primary key)
      - `appointment_id` (uuid, foreign key to appointments)
      - `investigation_id` (uuid, foreign key to investigations)
      - `result_value` (text)
      - `result_file_url` (text for PDF storage)
      - `is_abnormal` (boolean)
      - `notes` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `investigation_results` table
    - Add policy for authenticated users to manage investigation results
*/

CREATE TABLE IF NOT EXISTS investigation_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  investigation_id uuid NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
  result_value text DEFAULT '',
  result_file_url text DEFAULT '',
  is_abnormal boolean DEFAULT false,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE investigation_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage investigation results"
  ON investigation_results
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_investigation_results_appointment_id ON investigation_results(appointment_id);
CREATE INDEX IF NOT EXISTS idx_investigation_results_investigation_id ON investigation_results(investigation_id);