/*
  # Create finance table

  1. New Tables
    - `finance`
      - `id` (uuid, primary key)
      - `appointment_id` (uuid, foreign key to appointments)
      - `amount` (decimal, required)
      - `payment_type` (text, required - cash/card/insurance)
      - `date` (date, required)
      - `description` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `finance` table
    - Add policy for authenticated users to manage finance data
*/

CREATE TABLE IF NOT EXISTS finance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid REFERENCES appointments(id) ON DELETE SET NULL,
  amount decimal(10,2) NOT NULL CHECK (amount >= 0),
  payment_type text NOT NULL DEFAULT 'cash' CHECK (payment_type IN ('cash', 'card', 'insurance')),
  date date NOT NULL DEFAULT CURRENT_DATE,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE finance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage finance"
  ON finance
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_finance_appointment_id ON finance(appointment_id);
CREATE INDEX IF NOT EXISTS idx_finance_date ON finance(date);
CREATE INDEX IF NOT EXISTS idx_finance_payment_type ON finance(payment_type);